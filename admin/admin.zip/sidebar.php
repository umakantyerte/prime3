        <div class="sidebar" id="sidebar" style="background-color: black;">
            <div class="sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">
                    <ul>
                        <li class="menu-title">
                            <span>Main Menu</span>
                        </li>
                        <li class="active">
                            <a href="index.php"><i class="fas fa-th-large"></i> <span>Dashboard</span></a>
                        </li>
                        <li>
                            <a href="gallery.php"><i class="fas fa-book"></i> <span>Gallery</span></a>
                        </li>
                        <li>
                            <a href="properties.php"><i class="fas fa-building"></i><span>Our Properties</span></a>
                        </li>

                        <!-- <li>
                            <a href="coursesdesc.php"><i class="fas fa-book"></i> <span>Course Description</span></a>
                        </li> -->
                        <!-- <li>
                            <a href="coursecurriculum.php"><i class="fas fa-user-graduate"></i> <span>Course Curriculum</span></a>
                        </li>  -->
                        <li>
                            <a href="service.php"><i class="fas fa-cogs"></i><span>Service</span></a>
                        </li>

                        <li>
                            <a href="newproject.php"><i class="fas fa-folder-plus"></i><span>New Project</span></a>
                        </li>

                        <li>
                            <a href="Client.php"><i class="fas fa-user"></i><span>Client</span></a>
                        </li>


                        <!-- <li>
                            <a href="paiduser.php"><i class="fas fa-user-graduate"></i><span class="badge badge-success" style="margin-left: 0px;">Paid User</span></a>
                        </li> -->
                        <!-- <li>
                            <a href="contactdetailslist.php"><i class="fas fa-user-graduate"></i> <span>Contact Details</span></a>
                        </li> -->
                        <!-- <li>
                            <a href="studentlist.php"><i class="fas fa-user-graduate"></i> <span>Student</span></a>
                        </li>  -->
                        <li class="menu-title">
                            <span>Management</span>
                        </li>
                        <li class="submenu">
                            <a href="#"><i class="fas fa-shield-alt"></i> <span> Authentication </span> <span class="menu-arrow"></span></a>
                            <ul>
                                <li><a href="changepassword.php">Change Password</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </div>